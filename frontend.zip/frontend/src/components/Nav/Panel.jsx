import React, { useState, useEffect, useRef } from 'react';
import '../../css/Nav/Panel.css';
import avatar from '../../assets/avatar.png';
import apiClient from '../../api/apiClient';
// ***** PHẦN SỬA ĐỔI QUAN TRỌNG NHẤT LÀ Ở ĐÂY *****
// UserProfile component giờ đã nhận và sử dụng prop 'onClick'
const UserProfile = ({ name, onClick }) => (
  <div className="user-profile" onClick={onClick}>
    <span>{name || 'loading...'}</span>
    <img src={avatar} alt="Avatar người dùng" />
  </div>
);

const Panel = () => {
  // State để quản lý việc dropdown có đang mở hay không
  const [isDropdownOpen, setDropdownOpen] = useState(false);
  const dropdownRef = useRef(null); // Ref để tham chiếu đến khu vực dropdown

  // Hàm xử lý khi bấm vào nút Đăng xuất
  const handleLogout = () => {
    console.log("Người dùng đã đăng xuất!");
    // Tại đây, bạn sẽ gọi API hoặc dispatch action để xử lý logic đăng xuất
    setDropdownOpen(false); // Đóng dropdown sau khi bấm
  };

  // Effect để xử lý việc bấm ra ngoài component
  useEffect(() => {
    const handleClickOutside = (event) => {
      // Nếu dropdown đang mở và người dùng bấm ra ngoài khu vực của dropdownRef
      if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
        setDropdownOpen(false); // Đóng dropdown
      }
    };

    // Thêm event listener khi component được mount
    document.addEventListener('mousedown', handleClickOutside);
    
    // Dọn dẹp event listener khi component bị unmount
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []); // Mảng rỗng đảm bảo effect này chỉ chạy một lần

  return (
    <div className="panel">
      {/* Gắn ref vào đây để xác định khu vực cần theo dõi */}
      <div className="panel-content" >
        <UserProfile ref={dropdownRef}
          name="Tên người dùng"
          onClick={() => setDropdownOpen(!isDropdownOpen)} // Bấm để đảo ngược trạng thái dropdown
        />

        {/* Chỉ hiện dropdown menu khi isDropdownOpen là true */}
        {isDropdownOpen && (
          <div className="dropdown-menu">
            <button onClick={handleLogout} className="dropdown-item">
              Đăng xuất
            </button>
            {/* Bạn có thể thêm các mục khác ở đây, ví dụ: "Cài đặt tài khoản" */}
          </div>
        )}
      </div>
    </div>
  );
};

export default Panel;